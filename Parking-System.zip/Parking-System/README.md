# 🚗 Parking Management System (FIXED VERSION)

## 📌 Project Overview
UML-based Parking Management System for Software Engineering course.

## 🎯 Features
- Vehicle entry & exit management
- Parking slot allocation
- User roles (Admin, Operator, Driver)
- Fee calculation system
- Reporting system

## 📊 UML Diagrams
- Use Case Diagram
- Class Diagram
- Sequence Diagrams:
  - Entry
  - Exit
  - Search

## 🛠 Tools
- PlantUML
- GitHub

## 📁 Project Structure
```
Parking-System/
├── README.md
├── usecase.puml
├── class.puml
├── sequence-entry.puml
├── sequence-exit.puml
├── sequence-search.puml
```

## ▶ How to Run
1. Copy .puml content
2. Paste in https://www.planttext.com
3. Generate diagram
